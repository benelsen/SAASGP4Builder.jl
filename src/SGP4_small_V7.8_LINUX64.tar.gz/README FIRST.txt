          STANDARDIZED ASTRODYNAMIC ALGORITHMS LIBRARY 
		RELEASE PACKAGE README FILE	           				
		As of 27 March 2017

           Platform:   Windows 32-bit or 64-bit

THIS ASTRO STDS RELEASE PACKAGE CONTAINS THE FOLLOWING ITEMS:
   - Executable code for the Standardized Astrodynamic Algorithms in DLL (Dynamic Link Library) format.
   - Example driver programs that access the DLL files and provides a means to run the Standardized Astrodynamic Algorithms DLL.
   - Source code for the driver programs in several programming languages (if available).
   - Documentation for the Standardized Astrodynamic Algorithms in Compiled HTML format (CHM)
   - Programmers Guide that provides example code to implement the drivers in several programming languages
   - A test environment to verify the Standardized Astrodynamic Algorithms run correctly and produces valid results.
   - A VERDICT comparison program is included in this deliver that compares expected results with results of running the algorithm  

Note:  Assembly instructions if downloaded from the Space Analysis Resource Portal (SARP), https://halfway.peterson.af.mil/SARP or Space-		track.org website:
   - Due to file size restrictions, the delivery packages are split into Windows 32bit, Windows 64 bit, Linux 32 bit and Linux 64 bit
   
On some organization networks, running the executables or batch files is not possible if the files are loaded on a network drive.  Copying the files on to your local drive is recommended.

  
THIS STANDARDIZED ASTRODYNAMIC ALGORITHMS SGP4 PACKAGE IS ORGANIZED IN THE FOLLOWING DIRECTORY STRUCTURE:

           
           Software_Version_xxxxx (where xxxxx can be WIN32, WIN64, Linux32 or Linux64)
           .   .
           .   Documents        (Program Documentation)
           .   . 
           .   DriverExamples             (Driver Program examples using various programming languages)
           .   .
           .   .  <subdirs>                   (specifics for each programming language)
           .   .
           .   Lib                        (Astrodynamic Standards dlls and required runtime libraries)
           .   .
           .   Verify                     (Standalone Test Environment)
           .   .   .
           .   .   Baseline                   (A9 certified results)
           .   .   .
           .   .   Diff                       (delivered empty - diffs here after running script)
           .   .   .
           .   .   Execution                  (test cases, program environment, batch file)
           .   .   .  .
           .   .   TestResults                (delivered empty - results here after running script)
           .   .   .
           .   .   VERDICT                    (Dinh's comparison program & example run script)
           .   .   .   .
           .   .   .   Reports                     (delivered empty - results here after running script)

After installing the files on your local machines drive


 TEST VERIFICATION INFORMATION
   A fully functioning test environment is provided with this release package.  A single script can be run
   that will execute a series of test cases, compare the output produced against the set of certified 
   Astro Stds baseline results, and write the differences to a separate directory for easier comparisons.

   To run the test script, do the following:

      If the test script was run previously and you wish to save any files in the Verify\Diff directory, 
      rename the files using an extension other than .txt - the script deletes any existing .txt files 
      when run.    

      Run the Test Cases script located in the Verify\Execution directory.
         Run_Test_Cases.bat

      The script will run a series of test cases, write the results to the Verify\TestResults directory, 
      compare the results to the baselined output files located in the Verify\Baseline directory, and write
      any differences to the Verify\Diff directory.  The Diff directory should be examined after the Test 
      Case script finishes.  There should not be any numerical differences found in the results.

   After running the above Run_Test_Cases.bat script, the VERDICT program can be run.  (VERDICT will use the
   data produced by the test cases).   A example batch file, Run_VERDICT.bat, can be run to demonstrate a 
   typical use of the VERDICT program.

   To run the VERDICT program script, do the following:

      If the VERDICT script was run previously and you wish to save any files in the Verify\VERDICT\Reports 
      directory, rename the files using an extension other than .txt - the script deletes any existing 
      .txt files when run.    

      Run the VERDICT script located in the Verify\VERDICT directory.
         Run_VERDICT.bat

      The script will call the VERDICT program, passing parameters to specify the two files containing the
      data, plus information needed to extract the target data from each file.  The script will write the 
      results of the comparison to the Verify\VERDICT\Reports directory.

      The VERDICT program output will specify whether any differences in the target data were found.  If so, 
      the program will display the values and provide information on the magnitude of the differences.  

 USAGE NOTES:
      The included C_driver program is called with the following required and optional parameters.
      note: The input deck for SGP4 has changed from the V7.beta1 version. The start, stop, and step
            used to be passed as parameters.  These values are now specified in the input file.

       Usage    : C_Software inFile outFile [-Ilibpath] [-DlogFile]

          inFile    : File containing TLEs and 6P-Card (which controls start, stop times and step size)
          outFile   : Base name for five output files
          -IlibPath : Optional, Specified path "libpath" to the Astrodynamic Standards library.
		  -DlogFile : Optional logFile to enable writing debug data to the specified file
   
       ^^^ NOTE CHANGE IN SGP4 PARAMETER ORDER AND CONTENT FROM V5.4.2 AND v7.BETA1 ^^^

       The -I parameter would be used to tell the program to search for the Astro Stds dlls in a location
       other than the current directory.   If the -I parameter is used, do not place a space between the -I 
       and the pathname.  The pathname must end with a \ character. Example: -I..\..\Lib\

       note: The -I parameter will only find the Astro Stds dll files, not other required runtime libraries,
             so it might be easier to add the pathname to the PATH logical instead.


 EXTERNAL RUNTIME LIBRARIES
   Certain non-A9-developed runtime libraries may need to be copied to the location where the driver 
   program is run.  Alternately, the (Windows) PATH logical can be set to search a directory location for  
   the runtime libraries (as is done in the Run_Test_Cases batch file).

 OTHER NOTES:  
   The lib directory may contain 32 or 64-bit dll files depending on the Delivery Package.  A file list 
   is included in the lib directory to help identify the files (by date/size) in case of mixup. 

   The C language driver writes a log file to the execution directory.  This file needs to be writable.

