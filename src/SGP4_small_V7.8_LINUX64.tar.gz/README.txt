                             ASTRO STANDARD RELEASE PACKAGE README FILE	           As of 25 Sep 2012
                                     Astro Std:  SGP4
                                     Release:    V7.beta4
                                     Platform:   Linux 32-bit or 64-bit

 THIS ASTRO STDS RELEASE PACKAGE CONTAINS THE FOLLOWING ITEMS:
   - Executable code for the Astro Stds program in shared object (SO) format (note: named as *.dll).
   - Example driver programs that access the SO files and provides a means to run the Astro Stds program.
   - Source code for the example driver programs in several programming languages (if available).
   - Documentation for the Astro Stds program, in MS Office (PC) format 
   - A test environment to verify the Astro Stds program runs correctly and produces valid results.
   - Dinh's VERDICT comparison program is included in this delivery.  

   Note:  Assembly instructions if downloaded from the Space Analysis Resource Portal (SARP) website:
   - Due to file size restrictions on SARP, the delivery package is split into 2 separate downloads.
         a) SGP4_V7.beta4_LinuxNN_Part1.zip - All files except Baseline files.  (where NN = 32 or 64)
         b) SGP4_V7.beta4_LinuxNN_Part2.zip - Baseline files.                   (where NN = 32 or 64)

     Unzip Part1 first, which contains most files and the overall directory structure.
     Unzip Part2 and place files in the Verify/Baseline folder.
     
  
 THIS ASTRO STDS RELEASE PACKAGE IS ORGANIZED IN THE FOLLOWING DIRECTORY STRUCTURE:


           
           SGP4_V7.beta4_LinuxNN (where NN = 32 or 64)
           .   .
           .   _Documents_V7.beta4        (Program Documentation)
           .   . 
           .   DriverExamples             (Driver Program examples using various programming languages)
           .   .
           .   .  <subdirs>                   (specifics for each programming language)
           .   .
           .   Lib                        (Astrodynamic Standards dlls and required runtime libraries)
           .   .
           .   Verify                     (Standalone Test Environment)
           .   .   .
           .   .   Baseline                   (A9 certified results)
           .   .   .
           .   .   Diff                       (delivered empty - diffs here after running script)
           .   .   .
           .   .   Execution                  (test cases, program environment, batch file)
           .   .   .  .
           .   .   TestResults                (delivered empty - results here after running script)
           .   .   .
           .   .   VERDICT                    (Dinh's comparison program & example run script)
           .   .   .   .
           .   .   .   Reports                     (delivered empty - results here after running script)


 TEST VERIFICATION INFORMATION
   A fully functioning test environment is provided with this release package.  A single script can be run
   that will execute a series of test cases, compare the output produced against the set of certified 
   Astro Stds baseline results, and write the differences to a separate directory for easier comparisons.

   To run the test script, do the following:

      If the test script was run previously and you wish to save any files in the Verify/Diff directory, 
      rename the files using an extension other than .txt - the script deletes any existing .txt files 
      when run.    

      Run the Test Cases script located in the Verify/Execution directory.
         Run_Test_Cases.bat

      The script will run a series of test cases, write the results to the Verify/TestResults directory, 
      compare the results to the baselined output files located in the Verify/Baseline directory, and write
      any differences to the Verify/Diff directory.  The Diff directory should be examined after the Test 
      Case script finishes.  There should not be any numerical differences found in the results.

   After running the above Run_Test_Cases.bat script, the VERDICT program can be run.  (VERDICT will use the
   data produced by the test cases).   A example batch file, Run_VERDICT.bat, can be run to demonstrate a 
   typical use of the VERDICT program.

   To run the VERDICT program script, do the following:

      If the VERDICT script was run previously and you wish to save any files in the Verify/VERDICT/Reports 
      directory, rename the files using an extension other than .txt - the script deletes any existing 
      .txt files when run.    

      Run the VERDICT script located in the Verify/VERDICT directory.
         Run_VERDICT.bat

      The script will call the VERDICT program, passing parameters to specify the two files containing the
      data, plus information needed to extract the target data from each file.  The script will write the 
      results of the comparison to the Verify/VERDICT/Reports directory.

      The VERDICT program output will specify whether any differences in the target data were found.  If so, 
      the program will display the values and provide information on the magnitude of the differences.  

 USAGE NOTES:
      The included C_driver program is called with the following required and optional parameters.
      note: The input deck for SGP4 has changed from the V7.beta1 version. The start, stop, and step
            used to be passed as parameters.  These values are now specified in the input file.

       Usage    : C_Sgp4Prop inFile outFile [-Ilibpath]

          inFile    : File containing TLEs and 6P-Card (which controls start, stop times and step size)
          outFile   : Base name for five output files
          -IlibPath : Optional, Specified path "libpath" to the Astrodynamic Standards library.
   
       The -I parameter would be used to tell the program to search for the Astro Stds SO's in a location
       other than the current directory.   If the -I parameter is used, do not place a space between the -I 
       and the pathname.  The pathname must end with a / character.  Example: -I../../Lib/

 OTHER NOTES:  
   The lib directory may contain 32 or 64-bit dll files depending on the Delivery Package.  A file list 
   is included in the lib directory to help identify the files (by date/size) in case of mixup. 

   The C language driver writes a log file to the execution directory.  This file needs to be writable.
