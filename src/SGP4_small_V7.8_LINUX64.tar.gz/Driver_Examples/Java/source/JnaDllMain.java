// This wrapper file was generated automatically by the A3\GenDllWrappers program.
package afspc.astrostds.wrappers;
import java.io.*;
import java.io.Reader;
import java.util.Date;
import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Platform;
import com.sun.jna.PointerType;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.DoubleByReference;
import afspc.astrostds.utilities.Utility;



public class JnaDllMain
{
   // Provide the path to the dll/so
   // **************************************************************************
   // On Unix/Linux platforms: please RENAME the provided shared object (SO) from "DllMain.dll" to "libDllMain.so"
   // **************************************************************************
   public static final String dllName = "DllMain";

   public static final long ApPtr;

   static
   {
      Native.register(dllName);
      ApPtr = DllMainInit();
   }

   /**
   * Dummy function, used to make sure dependencies are satisfied
   */
   public static void Init()
   { }


   /**
   * This is the most important function call of the Standardized Astrodynamic Algorithms library. It returns a handle which can be used to access the 
   * static global data set needed by the Standardized Astrodynamic Algorithms DLLs to communicate among themselves. 
   * All other function calls within the API will use this handle, so make sure you save this function's return value. 
   * @return A handle to the global data set. You will pass this handle to other initialization functions within other DLLs in the API.
   */
   public static native long DllMainInit();


   /**
   * Returns information about the DllMain DLL. 
   * @param infoStr A string to hold the information about DllMain.dll.
   */
   public static native void DllMainGetInfo(byte[] infoStr);


   /**
   * Opens a log file and enables the writing of diagnostic information into it. 
   * All of the DLLs in the library will write diagnostic information into the log file once this function has been called.
   * @param fileName The name of the log file to use.
   * @return 0 if the file was opened successfully. Other values indicate an error.
   */
   public static native int OpenLogFile(String fileName);


   /**
   * Closes the currently open log file. 
   */
   public static native void CloseLogFile();


   /**
   * Writes a message into the log file.
   * @param msgStr A message to be written into the log file.
   */
   public static native void LogMessage(String msgStr);


   /**
   * Returns a character string describing the last error that occurred. 
   * @param lastErrMsg A string that stores the last logged error message. The message will be placed in the string you pass to this function.
   */
   public static native void GetLastErrMsg(byte[] lastErrMsg);


   /**
   * Returns a character string describing the last informational message that was recorded. 
   * @param lastInfoMsg A string that stores the last logged informational message. The message will be placed in the string you pass to this function.
   */
   public static native void GetLastInfoMsg(byte[] lastInfoMsg);


   /**
   * Returns a list of names of the Standardized Astrodynamic Algorithms DLLs that were initialized successfully.
   * @param initDllNames A string that stores names of the DLLs that were initialized successfully.
   */
   public static native void GetInitDllNames(byte[] initDllNames);
   
   // log message string length
   public static final int LOGMSGLEN = 128;   
   
   // DHN 06Feb12 - Increase file path length to 512 characters from 128 characters to handle longer file path
   public static final int FILEPATHLEN = 512;
   
   // DHN 10Feb12 - Uniformally using 512 characters to passing/receiving string in all Get/Set Field functions
   public static final int GETSETSTRLEN = 512;
   
   public static final int INFOSTRLEN = 128;
   
   // DHN 10Feb12 - All input card types' (elsets, ob, sensors, ...) can now have maximum of 512 characters
   public static final int INPUTCARDLEN = 512;
   
   // Element types (last digit of satKey)
   public static final int  
      ELTTYPE_TLE_SGP   = 1,    // Element type - SGP Tle type 0
      ELTTYPE_TLE_SGP4  = 2,    // Element type - SGP4 Tle type 2
      ELTTYPE_TLE_SP    = 3,    // Element type - SP Tle type 6
      ELTTYPE_SPVEC_B1P = 4,    // Element type - SP Vector
      ELTTYPE_VCM       = 5,    // Element type - VCM
      ELTTYPE_EXTEPH    = 6;    // Element type - External ephemeris
   
   //*******************************************************************************
   
   // Propagation types
   public static final int  
      PROPTYPE_GP  = 1,       // GP/SGP4 propagator
      PROPTYPE_SP  = 2,       // SP propagator
      PROPTYPE_X   = 3,       // External ephemeris
      PROPTYPE_UK  = 4;       // Unknown
   //*******************************************************************************
   
   // Add sat error 
   public static final int  
      BADSATKEY = -1,      // Bad satellite key
      DUPSATKEY =  0;      // Duplicate satellite key
   
   //*******************************************************************************
   // Options used in GetLoaded()   
   public static final int  
      IDX_ORDER_ASC   = 0,    // ascending order
      IDX_ORDER_DES   = 1,    // descending order
      IDX_ORDER_READ  = 2,    // order as read
      IDX_ORDER_QUICK = 9;    // tree traversal order
   
   //*******************************************************************************
      
// ========================= End of auto generated code ==========================
}
