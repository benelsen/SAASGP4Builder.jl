package afspc.astrostds.services;
import java.io.*;
import java.io.Reader;
import java.util.Date;
import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Platform;
import com.sun.jna.PointerType;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.DoubleByReference;
import afspc.astrostds.wrappers.JnaDllMain;
import afspc.astrostds.utilities.Utility;



public class SrvDllMain
{
   
   //  Return the last error message recorded to the caller
   public static String GetLastErrMsg()
   {
      byte[] errMsgArr = new byte[Utility.LOGMSGLEN];
      JnaDllMain.GetLastErrMsg(errMsgArr);

      return Utility.BytesToString(errMsgArr);
   }

      // Show last logged error message
   public static void ShowLastErrMsg()
   {
      System.out.println(GetLastErrMsg());
   }


   // Show last logged error message and exit
   public static void ShowMsgAndTerminate()
   {
      System.out.println(GetLastErrMsg());
      System.exit(0);
   }

   // <JCL> Write the last logged err msg to a file
   public static void WriteErrMsg(BufferedWriter outFile) throws IOException
   {
      outFile.write(GetLastErrMsg() + "\n");
   }

   
}
