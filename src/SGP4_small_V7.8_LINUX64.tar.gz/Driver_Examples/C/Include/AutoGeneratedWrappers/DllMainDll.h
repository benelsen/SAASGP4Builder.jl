// This wrapper file was generated automatically by the A3\GenDllWrappers program.

#ifndef DLLMAINDLL_H
#define DLLMAINDLL_H

#include "../DllUtils.h"

// Provide the path to the dll
#define DllMainDll "DllMain.dll"


// This is the most important function call of the Standardized Astrodynamic Algorithms library. It returns a handle which can be used to access the 
// static global data set needed by the Standardized Astrodynamic Algorithms DLLs to communicate among themselves. 
// All other function calls within the API will use this handle, so make sure you save this function's return value. 
// returns A handle to the global data set. You will pass this handle to other initialization functions within other DLLs in the API.
typedef __int64 (STDCALL *fnPtrDllMainInit)();


// Returns information about the DllMain DLL. 
// infoStr: A string to hold the information about DllMain.dll.
typedef void (STDCALL *fnPtrDllMainGetInfo)(char infoStr[128]);


// Opens a log file and enables the writing of diagnostic information into it. 
// All of the DLLs in the library will write diagnostic information into the log file once this function has been called.
// fileName: The name of the log file to use.
// returns 0 if the file was opened successfully. Other values indicate an error.
typedef int (STDCALL *fnPtrOpenLogFile)(char fileName[512]);


// Closes the currently open log file. 
typedef void (STDCALL *fnPtrCloseLogFile)();


// Writes a message into the log file.
// msgStr: A message to be written into the log file.
typedef void (STDCALL *fnPtrLogMessage)(char msgStr[128]);


// Returns a character string describing the last error that occurred. 
// lastErrMsg: A string that stores the last logged error message. The message will be placed in the string you pass to this function.
typedef void (STDCALL *fnPtrGetLastErrMsg)(char lastErrMsg[128]);


// Returns a character string describing the last informational message that was recorded. 
// lastInfoMsg: A string that stores the last logged informational message. The message will be placed in the string you pass to this function.
typedef void (STDCALL *fnPtrGetLastInfoMsg)(char lastInfoMsg[128]);


// Returns a list of names of the Standardized Astrodynamic Algorithms DLLs that were initialized successfully.
// initDllNames: A string that stores names of the DLLs that were initialized successfully.
typedef void (STDCALL *fnPtrGetInitDllNames)(char initDllNames[512]);

// log message string length
#define LOGMSGLEN   128    

// DHN 06Feb12 - Increase file path length to 512 characters from 128 characters to handle longer file path
#define FILEPATHLEN   512 

// DHN 10Feb12 - Uniformally using 512 characters to passing/receiving string in all Get/Set Field functions
#define GETSETSTRLEN   512 

#define INFOSTRLEN   128 

// DHN 10Feb12 - All input card types' (elsets, ob, sensors, ...) can now have maximum of 512 characters
#define INPUTCARDLEN   512 

// Element types (last digit of satKey)
static const int  
   ELTTYPE_TLE_SGP   = 1,    // Element type - SGP Tle type 0
   ELTTYPE_TLE_SGP4  = 2,    // Element type - SGP4 Tle type 2
   ELTTYPE_TLE_SP    = 3,    // Element type - SP Tle type 6
   ELTTYPE_SPVEC_B1P = 4,    // Element type - SP Vector
   ELTTYPE_VCM       = 5,    // Element type - VCM
   ELTTYPE_EXTEPH    = 6;    // Element type - External ephemeris

//*******************************************************************************

// Propagation types
static const int  
   PROPTYPE_GP  = 1,       // GP/SGP4 propagator
   PROPTYPE_SP  = 2,       // SP propagator
   PROPTYPE_X   = 3,       // External ephemeris
   PROPTYPE_UK  = 4;       // Unknown
//*******************************************************************************

// Add sat error 
static const int  
   BADSATKEY = -1,      // Bad satellite key
   DUPSATKEY =  0;      // Duplicate satellite key

//*******************************************************************************
// Options used in GetLoaded()   
static const int  
   IDX_ORDER_ASC   = 0,    // ascending order
   IDX_ORDER_DES   = 1,    // descending order
   IDX_ORDER_READ  = 2,    // order as read
   IDX_ORDER_QUICK = 9;    // tree traversal order

//*******************************************************************************
   



// DllMainDll's function pointers
fnPtrDllMainInit                    DllMainInit;
fnPtrDllMainGetInfo                 DllMainGetInfo;
fnPtrOpenLogFile                    OpenLogFile;
fnPtrCloseLogFile                   CloseLogFile;
fnPtrLogMessage                     LogMessage;
fnPtrGetLastErrMsg                  GetLastErrMsg;
fnPtrGetLastInfoMsg                 GetLastInfoMsg;
fnPtrGetInitDllNames                GetInitDllNames;



void LoadDllMainDll(const char* libPath);
void FreeDllMainDll();




#endif
// ========================= End of auto generated code ==========================
