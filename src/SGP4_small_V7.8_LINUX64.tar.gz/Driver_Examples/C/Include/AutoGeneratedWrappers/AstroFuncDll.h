// This wrapper file was generated automatically by the A3\GenDllWrappers program.

#ifndef ASTROFUNCDLL_H
#define ASTROFUNCDLL_H

#include "../DllUtils.h"

// Provide the path to the dll
#define AstroFuncDll "AstroFunc.dll"


// Initializes AstroFunc DLL for use in the program.
// apPtr: The handle that was returned from DllMainInit(). See the documentation for DllMain.dll for details.
// returns 0 if AstroFunc.dll is initialized successfully, non-0 if there is an error.
typedef int (STDCALL *fnPtrAstroFuncInit)(__int64 apPtr);


// Retrieves information about the current version of AstroFunc.dll. The information is placed in the string parameter you pass in.
// infoStr: A string to hold the information about AstroFunc.dll.
typedef void (STDCALL *fnPtrAstroFuncGetInfo)(char infoStr[128]);


// Converts a set of Keplerian elements to a set of equinoctial elements. 
// metricKep: The set of Keplerian elements to be converted.
// metricEqnx: The resulting set of equinoctial elements.
typedef void (STDCALL *fnPtrKepToEqnx)(double metricKep[6], double metricEqnx[6]);


// Converts a set of Keplerian elements to position and velocity vectors.
// metricKep: The set of Keplerian elements to be converted.
// pos: The resulting position vector.
// vel: The resulting velocity vector.
typedef void (STDCALL *fnPtrKepToPosVel)(double metricKep[6], double pos[3], double vel[3]);


// Converts a set of Keplerian elements to Ubar, Vbar, and Wbar vectors.
// metricKep: The set of Keplerian elements to be converted.
// uBar: The resulting ubar vector.
// vBar: The resulting vbar vector.
// wBar: The resulting wbar vector.
typedef void (STDCALL *fnPtrKepToUVW)(double metricKep[6], double uBar[3], double vBar[3], double wBar[3]);


// Converts a set of classical elements to a set of equinoctial elements. 
// metricClass: The set of classical elements to be converted.
// metricEqnx: The resulting set of equinoctial elements.
typedef void (STDCALL *fnPtrClassToEqnx)(double metricClass[6], double metricEqnx[6]);


// Converts a set of equinoctial elements to a set of classical elements.
// metricEqnx: The set of equinoctial elements to be converted.
// metricClass: The resulting set of classical elements.
typedef void (STDCALL *fnPtrEqnxToClass)(double metricEqnx[6], double metricClass[6]);


// Converts a set of equinoctial elements to a set of Keplerian elements. 
// metricEqnx: The set of equinoctial elements to be converted.
// metricKep: The resulting set of Keplerian elements.
typedef void (STDCALL *fnPtrEqnxToKep)(double metricEqnx[6], double metricKep[6]);


// Converts a set of equinoctial elements to position and velocity vectors.
// metricEqnx: The set of equinoctial elements to be converted.
// pos: The resulting position vector.
// vel: The resulting velocity vector.
typedef void (STDCALL *fnPtrEqnxToPosVel)(double metricEqnx[6], double pos[3], double vel[3]);


// Converts position and velocity vectors to a set of equinoctial elements.
// pos: The position vector to be converted.
// vel: The velocity vector to be converted.
// metricEqnx: The resulting set of equinoctial elements.
typedef void (STDCALL *fnPtrPosVelToEqnx)(double pos[3], double vel[3], double metricEqnx[6]);


// Converts position and velocity vectors to a set of equinoctial elements with the given mu value. 
// pos: The position vector to be converted.
// vel: The velocity vector to be converted.
// mu: The value of mu.
// metricEqnx: The resulting set of equinoctial elements.
typedef void (STDCALL *fnPtrPosVelMuToEqnx)(double pos[3], double vel[3], double mu, double metricEqnx[6]);


// Converts position and velocity vectors to a set of Keplerian elements.
// pos: The position vector to be converted.
// vel: The velocity vector to be converted.
// metricKep: The resulting set of Keplerian elements.
typedef void (STDCALL *fnPtrPosVelToKep)(double pos[3], double vel[3], double metricKep[6]);


// Converts position and velocity vectors to a set of Keplerian elements with the given value of mu.
// pos: The position vector to be converted.
// vel: The velocity vector to be converted.
// mu: The value of mu.
// metricKep: The resulting set of Keplerian elements.
typedef void (STDCALL *fnPtrPosVelMuToKep)(double pos[3], double vel[3], double mu, double metricKep[6]);


// Converts position and velocity vectors to U, V, W vectors. See the remarks section for details.
// pos: The position vector to be converted.
// vel: The velocity vector to be converted.
// uVec: The resulting U vector.
// vVec: The resulting V vector.
// wVec: The resulting W vector.
typedef void (STDCALL *fnPtrPosVelToUUVW)(double pos[3], double vel[3], double uVec[3], double vVec[3], double wVec[3]);


// Converts position and velocity vectors to U, V, W vectors. See the remarks section for details.
// pos: The position vector.
// vel: The velocity vector.
// uVec: The resulting U vector.
// vVec: The resulting V vector.
// wVec: The resulting W vector.
typedef void (STDCALL *fnPtrPosVelToPTW)(double pos[3], double vel[3], double uVec[3], double vVec[3], double wVec[3]);


// Solves Kepler's equation (M = E - e sin(E)) for the eccentric anomaly, E, by iteration.
// metricKep: The set of Keplerian elements for which to solve the equation.
// returns The eccentric anomaly.
typedef double (STDCALL *fnPtrSolveKepEqtn)(double metricKep[6]);


// Computes true anomaly from a set of Keplerian elements.
// metricKep: The set of Keplerian elements for which to compute true anomaly.
// returns The true anomaly in degrees.
typedef double (STDCALL *fnPtrCompTrueAnomaly)(double metricKep[6]);


// Converts mean motion N to semi-major axis A.
// n: Mean motion N (revs/day).
// returns The semi-major axis A (km).
typedef double (STDCALL *fnPtrNToA)(double n);


// Converts semi-major axis A to mean motion N.
// a: Semi-major axis A (km).
// returns The mean motion N (revs/day).
typedef double (STDCALL *fnPtrAToN)(double a);


// Converts Kozai mean motion to Brouwer mean motion.
// eccen: eccentricity
// incli: inclination (degrees)
// nKozai: Kozai mean motion (revs/day).
// returns Brouwer mean motion (revs/day).
typedef double (STDCALL *fnPtrKozaiToBrouwer)(double eccen, double incli, double nKozai);


// Converts Brouwer mean motion to Kozai mean motion.
// eccen: eccentricity
// incli: inclination (degrees)
// nBrouwer: Brouwer mean motion (revs/day).
// returns Kozai mean motion (revs/day).
typedef double (STDCALL *fnPtrBrouwerToKozai)(double eccen, double incli, double nBrouwer);


// Converts a set of osculating Keplerian elements to a set of mean Keplerian elements using method 9 algorithm.
// metricOscKep: The set of osculating Keplerian elements to be converted.
// metricMeanKep: The resulting set of mean Keplerian elements.
typedef void (STDCALL *fnPtrKepOscToMean)(double metricOscKep[6], double metricMeanKep[6]);


// Converts an ECI position vector XYZ to geodetic latitude, longitude, and height.
// thetaG: ThetaG - Greenwich mean sidereal time (rad).
// metricPos: The ECI (TEME of Date) position vector (km) to be converted.
// metricLLH: The resulting geodetic north latitude (degree), east longitude(degree), and height (km).
typedef void (STDCALL *fnPtrXYZToLLH)(double thetaG, double metricPos[3], double metricLLH[3]);


// Converts geodetic latitude, longitude, and height to an ECI position vector XYZ.
// thetaG: Theta - Greenwich mean sidereal time (rad).
// metricLLH: An array containing geodetic north latitude (degree), east longitude (degree), and height (km) to be converted.
// metricXYZ: The resulting ECI (TEME of Date) position vector (km).
typedef void (STDCALL *fnPtrLLHToXYZ)(double thetaG, double metricLLH[3], double metricXYZ[3]);


// Converts EFG position and velocity vectors to ECI position and velocity vectors.
// thetaG: Theta - Greenwich mean sidereal time (rad).
// posEFG: The EFG position vector (km) to be converted.
// velEFG: The EFG velocity vector (km/s) to be converted.
// posECI: The resulting ECI (TEME of Date) position vector (km).
// velECI: The resulting ECI (TEME of Date) velocity vector (km/s).
typedef void (STDCALL *fnPtrEFGToECI)(double thetaG, double posEFG[3], double velEFG[3], double posECI[3], double velECI[3]);


// Converts ECI position and velocity vectors to EFG position and velocity vectors.
// thetaG: Theta - Greenwich mean sidereal time (rad).
// posECI: The ECI (TEME of Date) position vector (km) to be converted.
// velECI: The ECI (TEME of Date) velocity vector (km/s) to be converted.
// posEFG: The resulting EFG position vector (km).
// velEFG: The resulting EFG velocity vector (km/s).
typedef void (STDCALL *fnPtrECIToEFG)(double thetaG, double posECI[3], double velECI[3], double posEFG[3], double velEFG[3]);


// Converts ECR position and velocity vectors to EFG position and velocity vectors.
// polarX: Polar motion X (arc-sec).
// polarY: Polar motion Y (arc-sec).
// posECR: The ECR position vector (km) to be converted.
// velECR: The ECR velocity vector (km/s) to be converted.
// posEFG: The resulting EFG position vector (km).
// velEFG: The resulting EFG velocity vector (km/s).
typedef void (STDCALL *fnPtrECRToEFG)(double polarX, double polarY, double posECR[3], double velECR[3], double posEFG[3], double velEFG[3]);


// Converts EFG position and velocity vectors to ECR position and velocity vectors.
// polarX: Polar motion X (arc-sec).
// polarY: Polar motion Y (arc-sec).
// posEFG: The EFG position vector (km) to be converted.
// velEFG: The EFG velocity vector (km/s) to be converted.
// posECR: The resulting ECR position vector (km).
// velECR: The resulting ECR velocity vector (km/s).
typedef void (STDCALL *fnPtrEFGToECR)(double polarX, double polarY, double posEFG[3], double velEFG[3], double posECR[3], double velECR[3]);


// Converts an EFG position vector to geodetic latitude, longitude, and height.
// posEFG: The EFG position vector (km) to be converted.
// metricLLH: The resulting geodetic north latitude (degree), east longitude (degree), and height (km).
typedef void (STDCALL *fnPtrEFGPosToLLH)(double posEFG[3], double metricLLH[3]);


// Converts geodetic latitude, longitude, and height to an EFG position vector.
// metricLLH: An Array containing the geodetic north latitude (degree), east longitude (degree), and height (km) to be converted.
// posEFG: The resulting EFG position vector (km).
typedef void (STDCALL *fnPtrLLHToEFGPos)(double metricLLH[3], double posEFG[3]);


// Rotates position and velocity vectors from J2000 to coordinates of the specified date, expressed in ds50TAI.
// spectr: Specifies whether to run in SPECTR compatibility mode. A value of 1 means Yes.
// nutationTerms: Nutation terms (4-106, 4:less accurate, 106:most acurate).
// ds50TAI: The date to rotate to coordinates of, expressed in days since 1950, TAI.
// posJ2K: The position vector from J2000.
// velJ2K: The velocity vector from J2000.
// posDate: The resulting position vector in coordinates of date, ds50TAI.
// velDate: The resulting velocity vector in coordinates of date, ds50TAI.
typedef void (STDCALL *fnPtrRotJ2KToDate)(int spectr, int nutationTerms, double ds50TAI, double posJ2K[3], double velJ2K[3], double posDate[3], double velDate[3]);


// Rotates position and velocity vectors from coordinates of date to J2000.
// spectr: Specifies whether to run in SPECTR compatibility mode. A value of 1 means Yes.
// nutationTerms: Nutation terms (4-106, 4:less accurate, 106:most acurate).
// ds50TAI: Time in days since 1950, TAI for which the coordinates of position and velocity vectors are currently expressed.
// posDate: The position vector from coordinates of Date.
// velDate: The velocity vector from coordinates of Date.
// posJ2K: The resulting position vector in coordinates of J2000.
// velJ2K: The resulting velocity vector in coordinates of J2000.
typedef void (STDCALL *fnPtrRotDateToJ2K)(int spectr, int nutationTerms, double ds50TAI, double posDate[3], double velDate[3], double posJ2K[3], double velJ2K[3]);


// Computes the Sun and Moon position at the specified time.
// ds50ET: The number of days since 1950, ET for which to compute the sun and moon position.
// uvecSun: The resulting sun position unit vector.
// sunVecMag: The resulting magnitude of the sun position vector (km).
// uvecMoon: The resulting moon position unit vector.
// moonVecMag: The resulting magnitude of the moon position vector (km).
typedef void (STDCALL *fnPtrCompSunMoonPos)(double ds50ET, double uvecSun[3], double* sunVecMag, double uvecMoon[3], double* moonVecMag);


// Computes the Sun position at the specified time.
// ds50ET: The number of days since 1950, ET for which to compute the sun position.
// uvecSun: The resulting sun position unit vector.
// sunVecMag: The resulting magnitude of the sun position vector (km).
typedef void (STDCALL *fnPtrCompSunPos)(double ds50ET, double uvecSun[3], double* sunVecMag);


// Computes the Moon position at the specified time.
// ds50ET: The number of days since 1950, ET for which to compute the moon position.
// uvecMoon: The resulting moon position unit vector.
// moonVecMag: The resulting magnitude of the moon position vector (km).
typedef void (STDCALL *fnPtrCompMoonPos)(double ds50ET, double uvecMoon[3], double* moonVecMag);


// This function is intended for future use.  No information is currently available.
// xf_Conv: Index of the conversion function
// frArr: The input array
// toArr: The resulting array
typedef void (STDCALL *fnPtrAstroConvFrTo)(int xf_Conv, double frArr[128], double toArr[128]);


// Converts right ascension and declination to vector triad LAD in topocentric equatorial coordinate system.
// RA: Right ascension (deg).
// dec: Declination (deg).
// L: The resulting unit vector from the station to the satellite (referred to the equatorial coordinate system axis).
// A_Tilde: The resulting unit vector perpendicular to the hour circle passing through the satellite, in the direction of increasing RA.
// D_Tilde: The resulting unit vector perpendicular to L and is directed toward the north, in the plane of the hour circle.
typedef void (STDCALL *fnPtrRADecToLAD)(double RA, double dec, double L[3], double A_Tilde[3], double D_Tilde[3]);


// Converts azimuth and elevation to vector triad LAD in topocentric horizontal coordinate system.
// az: Input azimuth (deg).
// el: Input elevation angle (deg).
// Lh: The resulting unit vector from the station to the satellite (referred to the horizon coordinate system axis).
// Ah: The resulting unit vector perpendicular to the hour circle passing through the satellite, in the direction of increasing Az.
// Dh: The resulting unit vector perpendicular to L and is directed toward the zenith, in the plane of the hour circle.
typedef void (STDCALL *fnPtrAzElToLAD)(double az, double el, double Lh[3], double Ah[3], double Dh[3]);


// Converts satellite ECI position/velocity vectors and sensor location to topocentric components.
// theta: Theta - local sidereal time(rad).
// lat: Station's astronomical latitude (deg). (+N) (-S)
// senPos: Sensor position in ECI (km).
// satPos: Satellite position in ECI (km).
// satVel: Satellite velocity in ECI (km/s).
// xa_topo: An array that stores the resulting topocentric components.
typedef void (STDCALL *fnPtrECIToTopoComps)(double theta, double lat, double senPos[3], double satPos[3], double satVel[3], double xa_topo[10]);


// Converts right ascension and declination in the topocentric reference frame to Azimuth/Elevation in the local horizon reference frame.
// thetaG: Theta - Greenwich mean sidereal time (rad).
// lat: Station's astronomical latitude (deg). (+N) (-S)
// lon: Station's astronomical longitude (deg). (+E) (-W)
// RA: Right ascension (deg)
// dec: Declination (deg)
// az: Azimuth (deg)
// el: Elevation (deg)
typedef void (STDCALL *fnPtrRaDecToAzEl)(double thetaG, double lat, double lon, double RA, double dec, double* az, double* el);


// Converts full state RAE (range, az, el, and their rates) to full state ECI (position and velocity)
// theta: Theta - local sidereal time(rad).
// astroLat: Astronomical latitude (ded).
// xa_rae: An array contains input data.
// senPos: Sensor position in ECI (km).
// satPos: Satellite position in ECI (km).
// satVel: Satellite velocity in ECI (km/s).
typedef void (STDCALL *fnPtrRAEToECI)(double theta, double astroLat, double xa_rae[6], double senPos[3], double satPos[3], double satVel[3]);


// Computes initial values for the SGP drag term NDOT and the SGP4 drag term BSTAR based upon eccentricity and semi-major axis.
// semiMajorAxis: Semi-major axis (km).
// eccen: Eccentricity (unitless).
// ndot: Ndot (revs/day^2).
// bstar: Bstar (1/earth radii).
typedef void (STDCALL *fnPtrGetInitialDrag)(double semiMajorAxis, double eccen, double* ndot, double* bstar);


// Converts covariance matrix PTW to UVW.
// pos: The input position vector (km).
// vel: The input velocity vector (km/s).
// ptwCovMtx: The PTW covariance matrix to be converted.
// uvwCovMtx: The resulting UVW covariance matrix.
typedef void (STDCALL *fnPtrCovMtxPTWToUVW)(double pos[3], double vel[3], double ptwCovMtx[6][6], double uvwCovMtx[6][6]);


// Converts covariance matrix UVW to PTW.
// pos: The input position vector (km).
// vel: The input velocity vector (km/s).
// uvwCovMtx: The UVW covariance matrix to be converted.
// ptwCovMtx: The resulting PTW covariance matrix.
typedef void (STDCALL *fnPtrCovMtxUVWToPTW)(double pos[3], double vel[3], double uvwCovMtx[6][6], double ptwCovMtx[6][6]);


// Computes Earth/Sensor/Earth Limb and Earth/Sensor/Satellite angles.
// earthLimb: Earth limb distance (km).
// satECI: Satellite position in ECI (km).
// senECI: Sensor position in ECI (km).
// earthSenLimb: The resulting earth/sensor/limb angle (deg).
// earthSenSat: The resulting earth/sensor/sat angle (deg).
// satEarthSen: The resulting sat/earth/sensor angle (deg).
typedef void (STDCALL *fnPtrEarthObstructionAngles)(double earthLimb, double satECI[3], double senECI[3], double* earthSenLimb, double* earthSenSat, double* satEarthSen);

// Index of Keplerian elements
static const int  
   XA_KEP_A     =   0,       // semi-major axis (km)
   XA_KEP_E     =   1,       // eccentricity (unitless)
   XA_KEP_INCLI =   2,       // inclination (deg)
   XA_KEP_MA    =   3,       // mean anomaly (deg)
   XA_KEP_NODE  =   4,       // right ascension of the asending node (deg)
   XA_KEP_OMEGA =   5;       // argument of perigee (deg)
   
// Index of classical elements
static const int  
   XA_CLS_N     =   0,       // N mean motion (revs/day)
   XA_CLS_E     =   1,       // eccentricity (unitless)
   XA_CLS_INCLI =   2,       // inclination (deg)
   XA_CLS_MA    =   3,       // mean anomaly (deg)
   XA_CLS_NODE  =   4,       // right ascension of the asending node (deg)
   XA_CLS_OMEGA =   5;       // argument of perigee (deg)

// Index of equinoctial elements
static const int  
   XA_EQNX_AF   =   0,       // Af (unitless) 
   XA_EQNX_AG   =   1,       // Ag (unitless)
   XA_EQNX_CHI  =   2,       // Chi (unitless)
   XA_EQNX_PSI  =   3,       // Psi (unitless)
   XA_EQNX_L    =   4,       // L mean longitude (deg)
   XA_EQNX_N    =   5;       // N mean motion (revs/day)
   
// Indexes of AstroConvFrTo
static const int  
   XF_CONV_SGP42SGP = 101;        // SGP4 (A, E, Incli, BStar) to SGP (Ndot, N2Dot)


// Indexes for topocentric components
static const int  
   XA_TOPO_RA    = 0,         // Right ascension (deg)
   XA_TOPO_DEC   = 1,         // Declination (deg)
   XA_TOPO_AZ    = 2,         // Azimuth (deg)
   XA_TOPO_EL    = 3,         // Elevation (deg)
   XA_TOPO_RANGE = 4,         // Range (km)
   XA_TOPO_RADOT = 5,         // Right ascension dot (deg/s)
   XA_TOPO_DECDOT= 6,         // Declincation dot (deg/s)
   XA_TOPO_AZDOT = 7,         // Azimuth dot (deg/s)
   XA_TOPO_ELDOT = 8,         // Elevation dot (deg/s)
   XA_TOPO_RANGEDOT = 9;      // Range dot (km/s)   
   
   
// Indexes for RAE components
static const int  
   XA_RAE_RANGE   = 0,        // Range (km)
   XA_RAE_AZ      = 1,        // Azimuth (deg)
   XA_RAE_EL      = 2,        // Elevation (deg)
   XA_RAE_RANGEDOT= 3,        // Range dot (km/s)   
   XA_RAE_AZDOT   = 4,        // Azimuth dot (deg/s)
   XA_RAE_ELDOT   = 5;        // Elevation dot (deg/s)
   



// AstroFuncDll's function pointers
fnPtrAstroFuncInit                  AstroFuncInit;
fnPtrAstroFuncGetInfo               AstroFuncGetInfo;
fnPtrKepToEqnx                      KepToEqnx;
fnPtrKepToPosVel                    KepToPosVel;
fnPtrKepToUVW                       KepToUVW;
fnPtrClassToEqnx                    ClassToEqnx;
fnPtrEqnxToClass                    EqnxToClass;
fnPtrEqnxToKep                      EqnxToKep;
fnPtrEqnxToPosVel                   EqnxToPosVel;
fnPtrPosVelToEqnx                   PosVelToEqnx;
fnPtrPosVelMuToEqnx                 PosVelMuToEqnx;
fnPtrPosVelToKep                    PosVelToKep;
fnPtrPosVelMuToKep                  PosVelMuToKep;
fnPtrPosVelToUUVW                   PosVelToUUVW;
fnPtrPosVelToPTW                    PosVelToPTW;
fnPtrSolveKepEqtn                   SolveKepEqtn;
fnPtrCompTrueAnomaly                CompTrueAnomaly;
fnPtrNToA                           NToA;
fnPtrAToN                           AToN;
fnPtrKozaiToBrouwer                 KozaiToBrouwer;
fnPtrBrouwerToKozai                 BrouwerToKozai;
fnPtrKepOscToMean                   KepOscToMean;
fnPtrXYZToLLH                       XYZToLLH;
fnPtrLLHToXYZ                       LLHToXYZ;
fnPtrEFGToECI                       EFGToECI;
fnPtrECIToEFG                       ECIToEFG;
fnPtrECRToEFG                       ECRToEFG;
fnPtrEFGToECR                       EFGToECR;
fnPtrEFGPosToLLH                    EFGPosToLLH;
fnPtrLLHToEFGPos                    LLHToEFGPos;
fnPtrRotJ2KToDate                   RotJ2KToDate;
fnPtrRotDateToJ2K                   RotDateToJ2K;
fnPtrCompSunMoonPos                 CompSunMoonPos;
fnPtrCompSunPos                     CompSunPos;
fnPtrCompMoonPos                    CompMoonPos;
fnPtrAstroConvFrTo                  AstroConvFrTo;
fnPtrRADecToLAD                     RADecToLAD;
fnPtrAzElToLAD                      AzElToLAD;
fnPtrECIToTopoComps                 ECIToTopoComps;
fnPtrRaDecToAzEl                    RaDecToAzEl;
fnPtrRAEToECI                       RAEToECI;
fnPtrGetInitialDrag                 GetInitialDrag;
fnPtrCovMtxPTWToUVW                 CovMtxPTWToUVW;
fnPtrCovMtxUVWToPTW                 CovMtxUVWToPTW;
fnPtrEarthObstructionAngles         EarthObstructionAngles;



void LoadAstroFuncDll(const char* libPath);
void FreeAstroFuncDll();




#endif
// ========================= End of auto generated code ==========================
